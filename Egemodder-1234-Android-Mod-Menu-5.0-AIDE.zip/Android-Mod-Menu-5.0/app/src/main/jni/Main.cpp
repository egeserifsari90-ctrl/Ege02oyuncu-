#include <list>
#include <vector>
#include <cstring>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <string>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.hpp"
#include "Menu/Menu.hpp"
#include "Menu/Jni.hpp"
#include "Includes/Macros.h"
#include "dobby.h"

// Egemodder 1234: menu-only preview. No game patches or hooks.
static bool unlocked = false;
static bool fly = false, infiniteJump = false, noclip = false;
static int speed = 1;

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    const char *features[] = {
        OBFUSCATE("Category_EGEMODDER 1234"),
        OBFUSCATE("RichTextView_Menu demo - does not change Super Bear Adventure"),
        OBFUSCATE("0_InputText_Enter access code"),
        OBFUSCATE("1_Toggle_Fly (preview)"),
        OBFUSCATE("2_Toggle_Infinite jump (preview)"),
        OBFUSCATE("3_Toggle_No Clip (preview)"),
        OBFUSCATE("4_SeekBar_Speed (preview)_1_10"),
        OBFUSCATE("5_Button_Lock and reset"),
        OBFUSCATE("RichTextView_Unlock with 1234. These switches are placeholders only.")
    };
    int count = sizeof(features) / sizeof(features[0]);
    jobjectArray result = env->NewObjectArray(count, env->FindClass("java/lang/String"), env->NewStringUTF(""));
    for (int i = 0; i < count; ++i) env->SetObjectArrayElement(result, i, env->NewStringUTF(features[i]));
    return result;
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName,
             jint value, jlong Lvalue, jboolean enabled, jstring input) {
    if (featNum == 0) {
        if (input) {
            const char *code = env->GetStringUTFChars(input, nullptr);
            unlocked = strcmp(code, "1234") == 0;
            env->ReleaseStringUTFChars(input, code);
        }
        if (!unlocked) { fly = infiniteJump = noclip = false; speed = 1; }
        return;
    }
    if (featNum == 5) {
        unlocked = fly = infiniteJump = noclip = false;
        speed = 1;
        return;
    }
    if (!unlocked) return;
    switch (featNum) {
        case 1: fly = enabled; break;
        case 2: infiniteJump = enabled; break;
        case 3: noclip = enabled; break;
        case 4: speed = value; break;
        default: break;
    }
}

// No game-specific IL2CPP offsets have been verified. Deliberately no hook/patch calls.
